<?php
/*
Plugin Name: Tech Companion
Plugin URI: 
Description: This is a companion plugin for Tech Theme.
Version: 1.0.0
Author: Muhammad Shahin
Author URI: 
License: GPLv2 or later
Text Domain: tech_companion
*/

function tech_companion_register_my_cpts_book()
{

 /**
  * Post Type: Books.
  */

 $labels = [
  "name" => esc_html__("Books", "tech"),
  "singular_name" => esc_html__("Book", "tech"),
  "add_new" => esc_html__("Add New Book", "tech"),
  "add_new_item" => esc_html__("Add New Book", "tech"),
  "featured_image" => esc_html__("Book Cover Image", "tech"),
 ];

 $args = [
  "label" => esc_html__("Books", "tech"),
  "labels" => $labels,
  "description" => "",
  "public" => true,
  "publicly_queryable" => true,
  "show_ui" => true,
  "show_in_rest" => true,
  "rest_base" => "",
  "rest_controller_class" => "WP_REST_Posts_Controller",
  "rest_namespace" => "wp/v2",
  "has_archive" => "books",
  "show_in_menu" => true,
  "show_in_nav_menus" => true,
  "delete_with_user" => false,
  "exclude_from_search" => false,
  "capability_type" => "post",
  "map_meta_cap" => true,
  "hierarchical" => false,
  "can_export" => false,
  "rewrite" => ["slug" => "book", "with_front" => true],
  "query_var" => true,
  "supports" => ["title", "editor", "thumbnail", "excerpt"],
  "show_in_graphql" => false,
 ];

 register_post_type("book", $args);
}

add_action('init', 'tech_companion_register_my_cpts_book');
